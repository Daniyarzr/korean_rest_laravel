<?php $__env->startSection('title', 'Заказ #' . str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    
                    <div class="mb-4">
                        <div class="bg-secondary rounded-circle d-inline-flex align-items-center justify-content-center" 
                            style="width: 100px; height: 100px;">
                            <?php
                                $firstLetter = mb_strtoupper(mb_substr(Auth::user()->name, 0, 1));
                            ?>
                            <span class="text-white fw-bold" style="font-size: 2.5rem;"><?php echo e($firstLetter); ?></span>
                        </div>
                    </div>
                    
                    <h5 class="mb-1"><?php echo e(Auth::user()->name); ?></h5>
                    <p class="text-muted small"><?php echo e(Auth::user()->email); ?></p>
                    
                    <hr class="my-3">
                    
                   
                    <div class="list-group list-group-flush">
                        <a href="<?php echo e(route('profile.index')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>">
                            <i class="bi bi-person me-2"></i> Мой профиль
                        </a>
                        <a href="<?php echo e(route('profile.orders')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.orders') ? 'active' : ''); ?>">
                            <i class="bi bi-bag me-2"></i> Мои заказы
                        </a>
                        <a href="<?php echo e(route('profile.reservations')); ?>"
                        class="list-group-item <?php echo e(request()->routeIs('profile.reservations') ? 'active' : ''); ?>">
                            <i class="bi bi-calendar-check me-2"></i> Мои бронирования
                        </a>
                        <a href="<?php echo e(route('profile.addresses')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.addresses') ? 'active' : ''); ?>">
                            <i class="bi bi-geo-alt me-2"></i> Адреса доставки
                        </a>
                        <a href="<?php echo e(route('profile.edit')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.edit') ? 'active' : ''); ?>">
                            <i class="bi bi-pencil me-2"></i> Редактировать профиль
                        </a>
                        <form  id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                           <?php echo csrf_field(); ?>
                           <div class="list-group-item list-group-item-action cnt-logout border-0" >
                            
                            <button class="btn-logout" type="submit">
                                <i   class="bi bi-box-arrow-right me-2"></i> 
                                Выйти</button>
                           </div>
                            
                        </form>
                    </div>
                </div>
            </div>
            <?php if(Auth::user()->role == 'admin' or Auth::user()->role == 'manager'): ?>
            <div class="btn-admin-panel">
                <a href="<?php echo e(route('admin.dashboard')); ?>">Войти в Админ панель</a>
            </div>
            <?php endif; ?>
        </div>

        
        <div class="col-md-8">
          
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('profile.orders')); ?>">Мои заказы</a></li>
                    <li class="breadcrumb-item active">Заказ #<?php echo e(str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?></li>
                </ol>
            </nav>
            
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="display-6 fw-bold">Заказ #<?php echo e(str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?></h1>
                <span class="badge 
                    <?php if($order->status == 'new'): ?> bg-warning text-dark
                    <?php elseif($order->status == 'processing'): ?> bg-info
                    <?php elseif($order->status == 'completed'): ?> bg-success
                    <?php elseif($order->status == 'cancelled'): ?> bg-danger
                    <?php else: ?> bg-secondary <?php endif; ?> 
                    px-4 py-2 fs-6 rounded-pill">
                    <?php if($order->status == 'new'): ?> Новый
                    <?php elseif($order->status == 'processing'): ?> В процессе
                    <?php elseif($order->status == 'completed'): ?> Завершен
                    <?php elseif($order->status == 'cancelled'): ?> Отменен
                    <?php else: ?> <?php echo e($order->status); ?> <?php endif; ?>
                </span>
            </div>
            
            <div class="row">
               
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm border-0 rounded-3 h-100">
                        <div class="card-body p-4">
                            <h5 class="card-title mb-4"><i class="bi bi-info-circle me-2"></i> Информация о заказе</h5>
                            
                            <div class="mb-3">
                                <small class="text-muted"><i class="bi bi-calendar me-1"></i> Дата и время</small>
                                <div class="fw-bold"><?php echo e($order->created_at->format('d.m.Y H:i')); ?></div>
                            </div>
                            
                            <div class="mb-3">
                                <small class="text-muted"><i class="bi bi-person me-1"></i> Имя заказчика</small>
                                <div class="fw-bold"><?php echo e($order->customer_name); ?></div>
                            </div>
                            
                            <div class="mb-3">
                                <small class="text-muted"><i class="bi bi-telephone me-1"></i> Телефон</small>
                                <div class="fw-bold"><?php echo e($order->phone); ?></div>
                            </div>
                            
                            <div class="mb-3">
                                <small class="text-muted"><i class="bi bi-geo-alt me-1"></i> Адрес доставки</small>
                                <div class="fw-bold"><?php echo e($order->delivery_address); ?></div>
                            </div>
                            
                            <div class="mb-3">
                                <small class="text-muted"><i class="bi bi-cash-coin me-1"></i> Способ оплаты</small>
                                <div class="fw-bold">
                                    <?php if($order->payment_method == 'cash'): ?>
                                        <i class="bi bi-cash text-success me-1"></i> Наличными курьеру
                                    <?php else: ?>
                                        <i class="bi bi-credit-card text-primary me-1"></i> Картой онлайн
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <?php if($order->notes): ?>
                            <div class="mt-4 pt-3 border-top">
                                <small class="text-muted"><i class="bi bi-chat-left-text me-1"></i> Комментарий</small>
                                <div class="mt-2 p-3 bg-light rounded-3">
                                    <?php echo e($order->notes); ?>

                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Правая колонка - Товары и сумма -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm border-0 rounded-3 h-100">
                        <div class="card-body p-4">
                            <h5 class="card-title mb-4"><i class="bi bi-basket me-2"></i> Состав заказа</h5>
                            
                            <div class="table-responsive mb-4">
                                <table class="table table-borderless">
                                    <tbody>
                                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="border-bottom">
                                            <td class="ps-0 py-3">
                                                <div class="d-flex align-items-center">
                                                    <?php if($item->dish->url_image): ?>
                                                        <img src="<?php echo e(asset('storage/' . $item->dish->url_image)); ?>" 
                                                             class="rounded-3 me-3" 
                                                             style="width: 50px; height: 50px; object-fit: cover;">
                                                    <?php endif; ?>
                                                    <div>
                                                        <h6 class="mb-1"><?php echo e($item->dish->name); ?></h6>
                                                        <div class="text-muted small">
                                                            <?php if($item->dish->is_spicy): ?>
                                                                <i class="bi bi-fire text-danger me-1"></i> Острое
                                                            <?php endif; ?>
                                                            <?php if($item->dish->is_vegetarian): ?>
                                                                <i class="bi bi-leaf text-success ms-2 me-1"></i> Вегетарианское
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="text-danger fw-bold mt-1">
                                                            <?php echo e(number_format($item->price, 0, '', ' ')); ?> ₽ × <?php echo e($item->quantity); ?>

                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="text-end fw-bold align-middle">
                                                <?php echo e(number_format($item->price * $item->quantity, 0, '', ' ')); ?> ₽
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Итого -->
                            <div class="border-top pt-4">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="text-muted">Товары (<?php echo e($order->items->sum('quantity')); ?> шт.)</span>
                                    <span class="fw-bold"><?php echo e(number_format($order->total, 0, '', ' ')); ?> ₽</span>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="text-muted">Доставка</span>
                                    <span class="text-success fw-bold">Бесплатно</span>
                                </div>
                                
                                <div class="border-top pt-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">К оплате</h5>
                                        <h3 class="text-danger mb-0"><?php echo e(number_format($order->total, 0, '', ' ')); ?> ₽</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Кнопки действий -->
            <div class="d-flex justify-content-between mt-4">
                <a href="<?php echo e(route('profile.orders')); ?>" class="btn btn-outline-danger rounded-pill px-4">
                    <i class="bi bi-arrow-left me-2"></i> Назад к заказам
                </a>
                
                <div class="d-flex gap-2">
                    <?php if($order->status == 'new'): ?>
                 <form action="<?php echo e(route('orders.cancel', $order)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <button type="submit" class="btn btn-outline-danger btn-sm rounded-pill px-3" 
                            onclick="return confirm('Вы уверены, что хотите отменить заказ?')">
                        <i class="bi bi-x-circle me-1"></i> Отменить
                    </button>
                </form>
                    <?php endif; ?>
                    
                    <a href="<?php echo e(route('menu.index')); ?>" class="btn btn-danger rounded-pill px-4">
                        <i class="bi bi-bag-plus me-2"></i> Сделать новый заказ
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/profile/order-show.blade.php ENDPATH**/ ?>