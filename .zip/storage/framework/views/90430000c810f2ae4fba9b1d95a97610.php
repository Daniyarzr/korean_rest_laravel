<?php $__env->startSection('title', 'Редактирование профиля'); ?>

<style>
    .list-group-item.active {
        background-color: #dc3545;
        border-color: #dc3545;
    }
    .card {
        border-radius: 10px;
    }
    .form-label {
        font-weight: 500;
    }
    .content-h100{
        min-height:100vh;
    }
     .btn-logout{
        border:0;
        background-color: #ffffff00;
        width: 100%;
        color:red;
    }
    .btn-logout:hover{
        color: rgb(121, 121, 121);
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container py-5 content-h100">
    <h1 class="text-center mb-5 display-5 fw-bold">Редактирование профиля</h1>
    
    <div class="row">
        
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <!-- Аватарка с буквой -->
                    <div class="mb-4">
                        <div class="bg-secondary rounded-circle d-inline-flex align-items-center justify-content-center shadow-sm" 
                             style="width: 100px; height: 100px;">
                            <span class="text-white fw-bold" style="font-size: 2.5rem;">
                                <?php echo e(strtoupper(mb_substr(Auth::user()->name, 0, 1))); ?>

                            </span>
                        </div>
                    </div>
                    
                    <h5 class="mb-1"><?php echo e(Auth::user()->name); ?></h5>
                    <p class="text-muted small"><?php echo e(Auth::user()->email); ?></p>
                    
                    <hr class="my-3">
                    
                    <!-- Меню навигации -->
                    <div class="list-group list-group-flush">
                        <a href="<?php echo e(route('profile.index')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>">
                            <i class="bi bi-person me-2"></i> Мой профиль
                        </a>
                        <a href="<?php echo e(route('profile.orders')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.orders') ? 'active' : ''); ?>">
                            <i class="bi bi-bag me-2"></i> Мои заказы
                        </a>
                        <a href="<?php echo e(route('profile.reservations')); ?>"
                        class="list-group-item <?php echo e(request()->routeIs('profile.reservations') ? 'active' : ''); ?>">
                            <i class="bi bi-calendar-check me-2"></i> Мои бронирования
                        </a>
                        <a href="<?php echo e(route('profile.edit')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.edit') ? 'active' : ''); ?>">
                            <i class="bi bi-pencil me-2"></i> Редактировать профиль
                        </a>
                       <form  id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                           <?php echo csrf_field(); ?>
                           <div class="list-group-item list-group-item-action cnt-logout border-0" >
                            
                            <button class="btn-logout" type="submit">
                                <i   class="bi bi-box-arrow-right me-2"></i> 
                                Выйти</button>
                           </div>
                            
                        </form>
                    </div>
                </div>
            </div>
            <?php if(Auth::user()->role == 'admin' or Auth::user()->role == 'manager'): ?>
            <div class="btn-admin-panel">
                <a href="<?php echo e(route('admin.users.index')); ?>">Войти в Админ панель</a>
            </div>
            <?php endif; ?>
        </div>

        
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h4 class="mb-0"><i class="bi bi-pencil-square me-2"></i> Изменение данных профиля</h4>
                </div>
                
                <div class="card-body">
                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <strong>Ошибка!</strong> Пожалуйста, проверьте введенные данные.
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle me-2"></i>
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                   
                    <form method="POST" action="<?php echo e(route('profile.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> 

                        
                        <div class="mb-4">
                            <h5 class="border-bottom pb-2 mb-3">Основная информация</h5>
                            
                            <div class="row">
                                
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label">
                                        <i class="bi bi-person me-1"></i> Имя *
                                    </label>
                                    <input type="text" 
                                           class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="name" 
                                           name="name" 
                                           value="<?php echo e(old('name', $user->name)); ?>"
                                           placeholder="Введите ваше имя"
                                           required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">
                                        <i class="bi bi-envelope me-1"></i> Email *
                                    </label>
                                    <input type="email" 
                                           class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="email" 
                                           name="email" 
                                           value="<?php echo e(old('email', $user->email)); ?>"
                                           placeholder="example@mail.com"
                                           required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label">
                                        <i class="bi bi-telephone me-1"></i> Телефон
                                    </label>
                                    <input type="tel" 
                                           class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="phone" 
                                           name="phone" 
                                           value="<?php echo e(old('phone', $user->phone)); ?>"
                                           placeholder="+7 (999) 123-45-67">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text">Необязательное поле</div>
                                </div>
                            </div>
                        </div>

                      
                        <div class="mb-4">
                            <h5 class="border-bottom pb-2 mb-3">Смена пароля</h5>
                            <p class="text-muted small mb-4">
                                <i class="bi bi-info-circle me-1"></i>
                                Заполняйте эти поля только если хотите изменить пароль
                            </p>
                            
                            <div class="row">
                               
                                <div class="col-md-6 mb-3">
                                    <label for="current_password" class="form-label">
                                        Текущий пароль
                                    </label>
                                    <input type="password" 
                                           class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="current_password" 
                                           name="current_password"
                                           placeholder="Введите текущий пароль">
                                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                
                                <div class="col-md-6 mb-3">
                                    <label for="new_password" class="form-label">
                                        Новый пароль
                                    </label>
                                    <input type="password" 
                                           class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="new_password" 
                                           name="new_password"
                                           placeholder="Минимум 8 символов">
                                    <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                
                                <div class="col-md-6 mb-3">
                                    <label for="new_password_confirmation" class="form-label">
                                        Подтверждение пароля
                                    </label>
                                    <input type="password" 
                                           class="form-control" 
                                           id="new_password_confirmation" 
                                           name="new_password_confirmation"
                                           placeholder="Повторите новый пароль">
                                    <div class="form-text">Пароли должны совпадать</div>
                                </div>
                            </div>
                        </div>

                        <!-- Кнопки -->
                        <div class="d-flex justify-content-between align-items-center mt-5">
                            <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-outline-secondary">
                                <i class="bi bi-arrow-left me-1"></i> Назад
                            </a>
                            
                            <div>
                                <button type="reset" class="btn btn-outline-secondary me-2">
                                    <i class="bi bi-x-circle me-1"></i> Сбросить
                                </button>
                                <button type="submit" class="btn btn-secondary">
                                    <i class="bi bi-check-circle me-1"></i> Сохранить изменения
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Дополнительная информация -->
            <div class="card shadow-sm mt-4">
                <div class="card-body">
                    <h6><i class="bi bi-info-circle me-2 text-danger"></i> Важная информация</h6>
                    <ul class="small text-muted mb-0">
                        <li>Поля помеченные * обязательны для заполнения</li>
                        <li>После изменения email потребуется подтверждение</li>
                        <li>Пароль должен содержать минимум 8 символов</li>
                        <li>Изменения вступают в силу сразу после сохранения</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/profile/edit.blade.php ENDPATH**/ ?>