



<?php $__env->startSection('content'); ?>
    <div class="profile-page">
        <div class="profile-container">
            <div class="profile-grid">

                
                <?php echo $__env->make('profile.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                
                <section class="profile-panel">
                    <div class="profile-panel__body lg">
                        <?php echo $__env->yieldContent('profile_content'); ?>
                    </div>
                </section>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/profile/layout.blade.php ENDPATH**/ ?>