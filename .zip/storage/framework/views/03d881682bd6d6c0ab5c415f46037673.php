

<?php $__env->startSection('title', 'Создать пользователя'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Создать пользователя</h1>
        <a class="btn" href="<?php echo e(route('admin.users.index')); ?>">← Назад к списку</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="<?php echo e(route('admin.users.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="name">Имя *</label>
                <input type="text" 
                       id="name" 
                       name="name" 
                       value="<?php echo e(old('name')); ?>" 
                       placeholder="Введите имя пользователя" 
                       required 
                       autofocus>
                <small>Максимум 255 символов</small>
            </div>

            <div class="form-group">
                <label for="email">Email *</label>
                <input type="email" 
                       id="email" 
                       name="email" 
                       value="<?php echo e(old('email')); ?>" 
                       placeholder="user@example.com" 
                       required>
                <small>Должен быть уникальным</small>
            </div>

            <div class="form-group">
                <label for="password">Пароль *</label>
                <input type="password" 
                       id="password" 
                       name="password" 
                       placeholder="Минимум 6 символов" 
                       required>
                <small>Минимум 6 символов</small>
            </div>

            <div class="form-group">
                <label for="role">Роль *</label>
                <select id="role" name="role" required>
                    <option value="" disabled selected>Выберите роль</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role); ?>" <?php echo e(old('role') == $role ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($role)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small>admin — полный доступ, manager — ограниченный, user — базовый</small>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn primary">Создать пользователя</button>
                <a class="btn" href="<?php echo e(route('admin.users.index')); ?>">Отмена</a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/admin/users/create.blade.php ENDPATH**/ ?>