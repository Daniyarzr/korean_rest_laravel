<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Личный кабинет'); ?></title>
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    
    <link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>">
    
    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <div class="container py-5 content-h100 fade-in">
        <h1 class="text-center mb-5 display-5 fw-bold"><?php echo $__env->yieldContent('page-title', 'Личный кабинет'); ?></h1>
        
        <div class="row">
            <!-- Боковое меню -->
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm profile-card">
                    <div class="card-body text-center">
                        <!-- Аватарка -->
                        <div class="mb-4">
                            <div class="profile-avatar">
                                <?php
                                    $firstLetter = strtoupper(mb_substr(Auth::user()->name, 0, 1));
                                ?>
                                <span class="profile-avatar-initial"><?php echo e($firstLetter); ?></span>
                            </div>
                        </div>
                        
                        <h5 class="mb-1"><?php echo e(Auth::user()->name); ?></h5>
                        <p class="text-muted small"><?php echo e(Auth::user()->email); ?></p>
                        
                        <!-- Роль пользователя -->
                        <?php if(Auth::user()->isAdmin() || Auth::user()->isManager()): ?>
                            <div class="mt-2">
                                <span class="admin-badge">
                                    <?php if(Auth::user()->isAdmin()): ?> Администратор
                                    <?php elseif(Auth::user()->isManager()): ?> Менеджер
                                    <?php endif; ?>
                                </span>
                            </div>
                        <?php endif; ?>
                        
                        <hr class="my-3">
                        
                        <!-- Меню навигации -->
                        <div class="list-group list-group-flush">
                            <a href="<?php echo e(route('profile.index')); ?>" 
                               class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>">
                                <i class="bi bi-person me-2"></i> Мой профиль
                            </a>
                            
                            <a href="<?php echo e(route('profile.orders')); ?>" 
                               class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.orders') ? 'active' : ''); ?>">
                                <i class="bi bi-bag me-2"></i> Мои заказы
                            </a>
                            
                            <a href="<?php echo e(route('profile.reservations')); ?>"
                               class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.reservations') ? 'active' : ''); ?>">
                                <i class="bi bi-calendar-check me-2"></i> Мои бронирования
                            </a>
                            
                            <a href="<?php echo e(route('profile.addresses')); ?>" 
                               class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.addresses') ? 'active' : ''); ?>">
                                <i class="bi bi-geo-alt me-2"></i> Адреса доставки
                            </a>
                            
                            <a href="<?php echo e(route('profile.edit')); ?>" 
                               class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.edit') ? 'active' : ''); ?>">
                                <i class="bi bi-pencil me-2"></i> Редактировать профиль
                            </a>
                            
                            <!-- Кнопка админки для админов и менеджеров -->
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isManager()): ?>
                                <a href="<?php echo e(route('admin.dashboard')); ?>" 
                                   class="list-group-item list-group-item-action">
                                    <i class="bi bi-speedometer2 me-2"></i> Панель администратора
                                </a>
                            <?php endif; ?>
                            
                            <a href="<?php echo e(route('logout')); ?>" 
                               class="list-group-item list-group-item-action text-danger"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="bi bi-box-arrow-right me-2"></i> Выйти
                            </a>
                            
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                        
                        <!-- Карточка доступа к админке -->
                        <?php if(Auth::user()->isAdmin() || Auth::user()->isManager()): ?>
                            <div class="mt-4 p-3 admin-access-card rounded">
                                <h6 class="fw-bold mb-2">
                                    <i class="bi bi-shield-check me-1"></i> Доступ к админке
                                </h6>
                                <p class="small mb-2">Вы можете управлять системой</p>
                                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-admin">
                                    <i class="bi bi-arrow-right-circle me-1"></i> Перейти в админку
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Основной контент -->
            <div class="col-md-8">
                <?php if(Auth::user()->isAdmin() || Auth::user()->isManager()): ?>
                    <!-- Быстрый доступ к админке (только для админов/менеджеров) -->
                    <div class="card shadow-sm mb-4 admin-access-card">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1">
                                    <i class="bi bi-shield-lock me-2"></i> Панель администратора
                                </h6>
                                <p class="small text-muted mb-0">Быстрый доступ к управлению системой</p>
                            </div>
                            <div class="d-flex gap-2">
                                <?php if(Auth::user()->isAdmin()): ?>
                                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-primary btn-sm">
                                        <i class="bi bi-people"></i> Пользователи
                                    </a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.dishes.index')); ?>" class="btn btn-outline-success btn-sm">
                                    <i class="bi bi-egg-fried"></i> Блюда
                                </a>
                                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-admin btn-sm">
                                    <i class="bi bi-speedometer2 me-1"></i> Дашборд
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Уведомления -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle me-2"></i>
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong>Ошибка!</strong> Пожалуйста, проверьте введенные данные.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Контент страницы -->
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    
    <!-- Скрипты -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Колледж\korean-restaurant\resources\views/profile-layout.blade.php ENDPATH**/ ?>