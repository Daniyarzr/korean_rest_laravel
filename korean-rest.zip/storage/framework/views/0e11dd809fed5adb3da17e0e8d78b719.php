

<?php $__env->startSection('content'); ?>
<div class="text-center mb-12">
    <h1 class="text-4xl font-bold text-gray-800 mb-4">Добро пожаловать в корейский ресторан</h1>
    <p class="text-xl text-gray-600">Насладитесь аутентичной корейской кухней</p>
</div>

<!-- Популярные блюда -->
<section class="mb-12">
    <h2 class="text-2xl font-bold mb-6">Популярные блюда</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__currentLoopData = $popularDishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-xl font-semibold mb-2"><?php echo e($dish->name); ?></h3>
            <p class="text-gray-600 mb-4"><?php echo e($dish->description); ?></p>
            <div class="flex justify-between items-center">
                <span class="text-2xl font-bold text-red-600"><?php echo e($dish->price); ?> ₽</span>
                <?php if($dish->is_spicy): ?>
                    <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-sm">🌶️ Острое</span>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<!-- Категории -->
<section>
    <h2 class="text-2xl font-bold mb-6">Наше меню</h2>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('menu.category', $category->slug)); ?>" 
           class="bg-white rounded-lg shadow-md p-6 text-center hover:shadow-lg transition">
            <div class="text-3xl mb-2">🍜</div>
            <h3 class="font-semibold"><?php echo e($category->name); ?></h3>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/menu/home.blade.php ENDPATH**/ ?>