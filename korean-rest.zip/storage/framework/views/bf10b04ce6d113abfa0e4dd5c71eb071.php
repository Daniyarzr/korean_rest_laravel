


<?php $__env->startSection('title', 'Мои заказы'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1 class="text-center mb-5 display-5 fw-bold">📋 Мои заказы</h1>
    
    <?php if($orders->isEmpty()): ?>
        <div class="alert alert-info text-center py-5 rounded-3" style="max-width: 600px; margin: 0 auto;">
            <div class="py-3">
                <i class="bi bi-bag-x display-1 text-muted mb-4"></i>
                <h4 class="alert-heading mb-3">Заказов пока нет</h4>
                <p class="mb-4">Сделайте свой первый заказ из нашего меню</p>
                <a href="<?php echo e(route('menu.index')); ?>" class="btn btn-danger rounded-pill px-4">
                    <i class="bi bi-arrow-left me-2"></i> Перейти в меню
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card shadow-sm border-0 rounded-3 mb-4">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h5 class="card-title mb-1">
                                    Заказ #<?php echo e(str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?>

                                </h5>
                                <div class="text-muted small">
                                    <i class="bi bi-calendar me-1"></i> <?php echo e($order->created_at->format('d.m.Y H:i')); ?>

                                </div>
                            </div>
                            <div class="text-end">
                                <span class="badge 
                                    <?php if($order->status == 'new'): ?> bg-warning text-dark
                                    <?php elseif($order->status == 'processing'): ?> bg-info
                                    <?php elseif($order->status == 'completed'): ?> bg-success
                                    <?php elseif($order->status == 'cancelled'): ?> bg-danger
                                    <?php else: ?> bg-secondary <?php endif; ?> 
                                    px-3 py-2 rounded-pill">
                                    <?php if($order->status == 'new'): ?> Новый
                                    <?php elseif($order->status == 'processing'): ?> В процессе
                                    <?php elseif($order->status == 'completed'): ?> Завершен
                                    <?php elseif($order->status == 'cancelled'): ?> Отменен
                                    <?php else: ?> <?php echo e($order->status); ?> <?php endif; ?>
                                </span>
                                <h4 class="text-danger mt-2"><?php echo e(number_format($order->total, 0, '', ' ')); ?> ₽</h4>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <small class="text-muted"><i class="bi bi-person me-1"></i> Имя</small>
                                    <div><?php echo e($order->customer_name); ?></div>
                                </div>
                                <div class="mb-2">
                                    <small class="text-muted"><i class="bi bi-telephone me-1"></i> Телефон</small>
                                    <div><?php echo e($order->phone); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <small class="text-muted"><i class="bi bi-geo-alt me-1"></i> Адрес доставки</small>
                                    <div><?php echo e($order->delivery_address); ?></div>
                                </div>
                                <div class="mb-2">
                                    <small class="text-muted"><i class="bi bi-cash-coin me-1"></i> Способ оплаты</small>
                                    <div>
                                        <?php if($order->payment_method == 'cash'): ?>
                                            Наличными курьеру
                                        <?php else: ?>
                                            Картой онлайн
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if($order->notes): ?>
                        <div class="alert alert-light border rounded-3 mb-3">
                            <small class="text-muted"><i class="bi bi-chat-left-text me-1"></i> Комментарий к заказу</small>
                            <div class="mt-1"><?php echo e($order->notes); ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Товары в заказе -->
                        <div class="border-top pt-3">
                            <h6 class="mb-3">Состав заказа:</h6>
                            <div class="table-responsive">
                                <table class="table table-borderless table-sm">
                                    <tbody>
                                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="border-bottom">
                                            <td class="ps-0 py-2">
                                                <div class="d-flex align-items-center">
                                                    <?php if($item->dish->url_image): ?>
                                                        <img src="<?php echo e(asset('storage/' . $item->dish->url_image)); ?>" 
                                                             class="rounded-3 me-3" 
                                                             style="width: 40px; height: 40px; object-fit: cover;">
                                                    <?php endif; ?>
                                                    <div>
                                                        <div class="fw-bold"><?php echo e($item->dish->name); ?></div>
                                                        <div class="text-muted small"><?php echo e(number_format($item->price, 0, '', ' ')); ?> ₽ × <?php echo e($item->quantity); ?></div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="text-end fw-bold">
                                                <?php echo e(number_format($item->price * $item->quantity, 0, '', ' ')); ?> ₽
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <!-- Кнопки действий -->
                        <div class="d-flex justify-content-end gap-2 mt-3">
                            <a href="<?php echo e(route('orders.show', $order)); ?>" class="btn btn-outline-primary btn-sm rounded-pill px-3">
                                <i class="bi bi-eye me-1"></i> Подробнее
                            </a>
                            <?php if($order->status == 'new'): ?>
                            <form action="#" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-outline-danger btn-sm rounded-pill px-3" 
                                        onclick="return confirm('Отменить заказ?')">
                                    <i class="bi bi-x-circle me-1"></i> Отменить
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/orders/index.blade.php ENDPATH**/ ?>