

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Забронировать столик</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('reservations.store')); ?>">
        <?php echo csrf_field(); ?>

           <div class="mb-3">
                <label>Имя</label>
                <input type="text" class="form-control" value="<?php echo e(auth()->user()->name); ?>" readonly>
                <small class="text-muted">Имя берется из вашего профиля</small>
            </div>

            
            <input type="hidden" name="name" value="<?php echo e(auth()->user()->name); ?>">


        <div class="mb-3">
            <label>Телефон</label>
            <input type="tel" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>" required>
        </div>

        <div class="mb-3">
            <label>Дата</label>
            <select name="date" id="res-date" class="form-control" required>
                <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($date['value']); ?>" <?php echo e(old('date', $today) === $date['value'] ? 'selected' : ''); ?>>
                        <?php echo e($date['label']); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Время</label>
            <select name="time" id="res-time" class="form-control" required>
                <?php $__currentLoopData = $timesToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($time); ?>" <?php echo e(old('time') === $time ? 'selected' : ''); ?>>
                        <?php echo e($time); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Количество гостей</label>
            <input type="number" name="guests" class="form-control" min="1" max="20" value="<?php echo e(old('guests', 2)); ?>" required>
        </div>

        <div class="mb-3">
            <label>Комментарий (необязательно)</label>
            <textarea name="comment" class="form-control" rows="3"><?php echo e(old('comment')); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Забронировать</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const dateSelect = document.getElementById('res-date');
        const timeSelect = document.getElementById('res-time');
        const timesToday = <?php echo json_encode($timesToday, 15, 512) ?>;
        const otherTimes = <?php echo json_encode($times, 15, 512) ?>;
        const today = <?php echo json_encode($today, 15, 512) ?>;
        const oldTime = <?php echo json_encode(old('time'), 15, 512) ?>;

        function updateTimes() {
            const selectedDate = dateSelect.value;
            const times = (selectedDate === today) ? timesToday : otherTimes;
            
            timeSelect.innerHTML = '';
            
            if (times.length === 0) {
                timeSelect.innerHTML = '<option value="">Нет доступного времени</option>';
                return;
            }
            
            times.forEach(time => {
                const option = new Option(time, time);
                timeSelect.add(option);
            });
            
            if (oldTime && times.includes(oldTime)) {
                timeSelect.value = oldTime;
            }
        }

        dateSelect.addEventListener('change', updateTimes);
        updateTimes();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/reservations/create.blade.php ENDPATH**/ ?>