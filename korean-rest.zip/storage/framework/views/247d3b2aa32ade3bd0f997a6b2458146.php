

<?php $__env->startSection('title', 'Редактировать блюдо'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Редактировать блюдо #<?php echo e($dish->id); ?></h1>
        <a class="btn" href="<?php echo e(route('admin.dishes.index')); ?>">← Назад к списку</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="<?php echo e(route('admin.dishes.update', $dish)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name">Название блюда *</label>
                <input type="text" 
                       id="name" 
                       name="name" 
                       value="<?php echo e(old('name', $dish->name)); ?>" 
                       placeholder="Например: Пицца Маргарита" 
                       required 
                       autofocus>
                <small>Максимум 255 символов</small>
            </div>

            <div class="form-group">
                <label for="price">Цена *</label>
                <input type="number" 
                       id="price" 
                       name="price" 
                       value="<?php echo e(old('price', $dish->price)); ?>" 
                       placeholder="0" 
                       min="0" 
                       step="1" 
                       required>
                <small>Цена в рублях</small>
            </div>

            <div class="form-group">
                <label for="description">Описание</label>
                <textarea id="description" 
                          name="description" 
                          rows="4" 
                          placeholder="Подробное описание блюда..."><?php echo e(old('description', $dish->description)); ?></textarea>
                <small>Необязательное поле</small>
            </div>

            <div class="dish-info mt-4 p-3 bg-gray-50 rounded">
                <h3 class="font-semibold">Информация о блюде</h3>
                <p><strong>Создано:</strong> <?php echo e($dish->created_at->format('d.m.Y H:i')); ?></p>
                <p><strong>Обновлено:</strong> <?php echo e($dish->updated_at->format('d.m.Y H:i')); ?></p>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn primary">Сохранить изменения</button>
                <a class="btn" href="<?php echo e(route('admin.dishes.index')); ?>">Отмена</a>
                
                <form method="POST" 
                      action="<?php echo e(route('admin.dishes.destroy', $dish)); ?>" 
                      class="inline-form"
                      onsubmit="return confirm('Вы уверены, что хотите удалить это блюдо?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn danger">Удалить блюдо</button>
                </form>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/admin/dishes/edit.blade.php ENDPATH**/ ?>