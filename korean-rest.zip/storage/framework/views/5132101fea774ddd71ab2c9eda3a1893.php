

<?php $__env->startSection('title', 'Контакты'); ?>

<?php $__env->startSection('content'); ?>
<div class="contacts-page">

    
    <section class="contacts-hero">
        <div class="contacts-hero__overlay"></div>

        <div class="container contacts-hero__content">
            <h1>Контакты</h1>
            <p class="text-white">Свяжитесь с нами удобным для вас способом</p>
        </div>
    </section>

    
    <section class="section contacts-main">
        <div class="container">
            <div class="contacts-grid">

                
                <div class="contacts-card">
                    <h3>Наши контакты</h3>

                    <div class="contact-item">
                        <span>📍</span>
                        <div>
                            <strong>Адрес</strong>
                            <p>г. Москва, ул. Примерная, 10</p>
                        </div>
                    </div>

                    <div class="contact-item">
                        <span>📞</span>
                        <div>
                            <strong>Телефон</strong>
                            <p>
                                <a href="tel:+79990000000">
                                    +7 (999) 000-00-00
                                </a>
                            </p>
                        </div>
                    </div>

                    <div class="contact-item">
                        <span>✉️</span>
                        <div>
                            <strong>Email</strong>
                            <p>
                                <a href="mailto:info@example.com">
                                    info@example.com
                                </a>
                            </p>
                        </div>
                    </div>

                    <div class="contact-item">
                        <span>🕒</span>
                        <div>
                            <strong>График работы</strong>
                            <p>Пн–Пт: 09:00 – 18:00</p>
                        </div>
                    </div>
                </div>

                
                <div class="contacts-map">
                    <iframe
                        src="https://www.google.com/maps?q=Москва&output=embed"
                        loading="lazy">
                    </iframe>
                </div>

            </div>
        </div>
    </section>

    
    <section class="section contacts-form">
        <div class="container">
            <div class="form-card">
                <h3>Напишите нам</h3>

                <form method="POST" action="#">
                    <?php echo csrf_field(); ?>

                    <div class="form-grid">
                        <input type="text" placeholder="Ваше имя" required>
                        <input type="email" placeholder="Email" required>
                        <textarea rows="4" placeholder="Сообщение" required></textarea>
                        <button class="btn-primary">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/contacts.blade.php ENDPATH**/ ?>