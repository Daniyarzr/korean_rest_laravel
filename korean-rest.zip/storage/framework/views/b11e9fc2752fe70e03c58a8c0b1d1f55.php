

<?php $__env->startSection('title', 'Админ панель|Пользователи'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Пользователи</h1>

        <div class="actions">
            <form method="GET" class="search">
                <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Поиск по имени/email">
                <button type="submit">Найти</button>
            </form>

            <a class="btn" href="<?php echo e(route('admin.users.create')); ?>">+ Создать</a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert error"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="card">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Имя</th>
                    <th>Email</th>
                    <th>Роль</th>
                    <th style="width: 220px;">Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>#<?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><span class="badge"><?php echo e($user->role); ?></span></td>
                        <td class="row-actions">
                            <a class="btn small" href="<?php echo e(route('admin.users.edit', $user)); ?>">Редактировать</a>

                            <form method="POST" action="<?php echo e(route('admin.users.destroy', $user)); ?>"
                                  onsubmit="return confirm('Удалить пользователя?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn small danger" type="submit">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5">Ничего не найдено.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt">
        <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/admin/users/index.blade.php ENDPATH**/ ?>