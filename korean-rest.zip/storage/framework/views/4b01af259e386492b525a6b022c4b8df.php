
<aside class="profile-panel">
    <div class="user-card">
        <?php
            $u = Auth::user();
            $label = $u?->name ?: ($u?->email ?: 'U');
            $firstLetter = strtoupper(mb_substr($label, 0, 1));
        ?>

        <div class="user-head">
            <div class="user-avatar" aria-hidden="true"><?php echo e($firstLetter); ?></div>

            <div class="user-meta">
                <p class="user-name"><?php echo e($u->name ?? 'Пользователь'); ?></p>
                <p class="user-email"><?php echo e($u->email ?? ''); ?></p>
            </div>
        </div>

        <div class="profile-divider"></div>

        <nav class="profile-nav">
            <a href="<?php echo e(route('profile.index')); ?>" class="<?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>">
                <span>Мой профиль</span>
            </a>

            <a href="<?php echo e(route('profile.orders')); ?>" class="<?php echo e(request()->routeIs('profile.orders*') ? 'active' : ''); ?>">
                <span>Мои заказы</span>
            </a>

            <a href="<?php echo e(route('profile.reservations')); ?>" class="<?php echo e(request()->routeIs('profile.reservations*') ? 'active' : ''); ?>">
                <span>Мои бронирования</span>
            </a>

            <a href="<?php echo e(route('profile.edit')); ?>" class="<?php echo e(request()->routeIs('profile.edit') ? 'active' : ''); ?>">
                <span>Редактировать</span>
            </a>

            <a href="<?php echo e(route('logout')); ?>" class="danger"
               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <span>Выйти</span>
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </nav>
    </div>
</aside>
<?php /**PATH D:\Колледж\korean-restaurant\resources\views/profile/sidebar.blade.php ENDPATH**/ ?>