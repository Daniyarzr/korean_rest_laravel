

<?php $__env->startSection('title', 'Админ панель|Блюда'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Блюда</h1>
        <div class="actions">
            <a class="btn" href="<?php echo e(route('admin.dishes.create')); ?>">+ Создать блюдо</a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <?php if($dishes->count() > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Название</th>
                        <th>Описание</th>
                        <th>Цена</th>
                        <th>Дата создания</th>
                        <th style="width: 200px;">Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>#<?php echo e($dish->id); ?></td>
                            <td><?php echo e($dish->name); ?></td>
                            <td><?php echo e(Str::limit($dish->description ?? '—', 50)); ?></td>
                            <td><?php echo e(number_format($dish->price, 0, '', ' ')); ?> ₽</td>
                            <td><?php echo e($dish->created_at->format('d.m.Y')); ?></td>
                            <td class="row-actions">
                                <a class="btn small" href="<?php echo e(route('admin.dishes.edit', $dish)); ?>">
                                    Редактировать
                                </a>
                                
                                <form method="POST" 
                                      action="<?php echo e(route('admin.dishes.destroy', $dish)); ?>"
                                      onsubmit="return confirm('Удалить блюдо?');"
                                      class="inline-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn small danger" type="submit">Удалить</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="p-6 text-center text-gray-500">
                Блюд пока нет. <a href="<?php echo e(route('admin.dishes.create')); ?>" class="underline">Создайте первое блюдо</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-4">
        <?php echo e($dishes->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/admin/dishes/index.blade.php ENDPATH**/ ?>