<?php $__env->startSection('title', 'Мои бронирования'); ?>
<style>
    .list-group-item.active {
        background-color: #dc3545;
        border-color: #dc3545;
    }
    .list-group-item:hover {
        background-color: #f8f9fa;
    }
    .card {
        border-radius: 10px;
        border: 1px solid rgba(0,0,0,.125);
    }
    .content-h100{
        min-height:100vh;
    }
    .btn-logout{
        border:0;
        background-color: #ffffff00;
        width: 100%;
        color:red;
    }
    .btn-logout:hover{
        color: rgb(121, 121, 121);
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        
       <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    
                    <div class="mb-4">
                        <div class="bg-secondary rounded-circle d-inline-flex align-items-center justify-content-center" 
                            style="width: 100px; height: 100px;">
                            <?php
                                $firstLetter = mb_strtoupper(mb_substr(Auth::user()->name, 0, 1));
                            ?>
                            <span class="text-white fw-bold" style="font-size: 2.5rem;"><?php echo e($firstLetter); ?></span>
                        </div>
                    </div>
                    
                    <h5 class="mb-1"><?php echo e(Auth::user()->name); ?></h5>
                    <p class="text-muted small"><?php echo e(Auth::user()->email); ?></p>
                    
                    <hr class="my-3">
                    
                    
                    <div class="list-group list-group-flush">
                        <a href="<?php echo e(route('profile.index')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>">
                            <i class="bi bi-person me-2"></i> Мой профиль
                        </a>
                        <a href="<?php echo e(route('profile.orders')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.orders') ? 'active' : ''); ?>">
                            <i class="bi bi-bag me-2"></i> Мои заказы
                        </a>
                        <a href="<?php echo e(route('profile.reservations')); ?>"
                        class="list-group-item <?php echo e(request()->routeIs('profile.reservations') ? 'active' : ''); ?>">
                            <i class="bi bi-calendar-check me-2"></i> Мои бронирования
                        </a>
                        <a href="<?php echo e(route('profile.edit')); ?>" 
                           class="list-group-item list-group-item-action <?php echo e(request()->routeIs('profile.edit') ? 'active' : ''); ?>">
                            <i class="bi bi-pencil me-2"></i> Редактировать профиль
                        </a>
                        <form  id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                           <?php echo csrf_field(); ?>
                           <div class="list-group-item list-group-item-action cnt-logout border-0" >
                            
                            <button class="btn-logout" type="submit">
                                <i   class="bi bi-box-arrow-right me-2"></i> 
                                Выйти</button>
                           </div>
                            
                        </form>
                    </div>
                </div>
            </div>
            <?php if(Auth::user()->role == 'admin' or Auth::user()->role == 'manager'): ?>
            <div class="btn-admin-panel">
                <a href="<?php echo e(route('admin.users.index')); ?>">Войти в Админ панель</a>
            </div>
            <?php endif; ?>
        </div>

       
        <div class="col-md-8">
            <div class="card shadow-sm mb-4">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><i class="bi bi-calendar-check me-2"></i> Мои бронирования</h4>
                    <div class="text-muted small">
                        Всего: <span class="badge bg-danger"><?php echo e($reservations->total()); ?></span>
                    </div>
                </div>
            </div>

            

            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if($reservations->count() === 0): ?>
                <div class="card shadow-sm">
                    <div class="card-body text-center text-muted">
                        Бронирований пока нет.
                    </div>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card shadow-sm mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <div class="text-muted small mb-1">Дата и время</div>
                                    <div class="fw-semibold h5">
                                        <?php echo e(\Illuminate\Support\Carbon::parse($r->date)->format('d.m.Y')); ?>

                                        <?php echo e(\Illuminate\Support\Carbon::parse($r->time)->format('H:i')); ?>

                                    </div>
                                </div>

                                <span class="badge 
                                    <?php if($r->status === 'new'): ?> bg-warning text-dark
                                    <?php elseif($r->status === 'confirmed'): ?> bg-success
                                    <?php elseif($r->status === 'cancelled'): ?> bg-secondary
                                    <?php else: ?> bg-info
                                    <?php endif; ?>
                                ">
                                    <?php if($r->status === 'new'): ?> Новая
                                    <?php elseif($r->status === 'confirmed'): ?> Подтверждена
                                    <?php elseif($r->status === 'cancelled'): ?> Отменена
                                    <?php else: ?> <?php echo e($r->status); ?>

                                    <?php endif; ?>
                                </span>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="text-muted small">Гостей</div>
                                    <div class="fw-medium"><?php echo e($r->guests); ?> чел.</div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="text-muted small">Телефон</div>
                                    <div class="fw-medium"><?php echo e($r->phone); ?></div>
                                </div>
                            </div>

                            <?php if($r->comment): ?>
                                <div class="mb-3">
                                    <div class="text-muted small">Комментарий</div>
                                    <div><?php echo e($r->comment); ?></div>
                                </div>
                            <?php endif; ?>

                            <?php if($r->status === 'new' || $r->status === 'confirmed'): ?>
                                <div class="d-flex justify-content-between align-items-center border-top pt-3">
                                    <small class="text-muted">
                                        Создано: <?php echo e($r->created_at->format('d.m.Y H:i')); ?>

                                    </small>
                                    
                                    <button type="button" 
                                            class="btn btn-outline-danger btn-sm" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#cancelModal<?php echo e($r->id); ?>">
                                        <i class="bi bi-x-circle me-1"></i> Отменить
                                    </button>
                                </div>
                            <?php else: ?>
                                <div class="border-top pt-3">
                                    <small class="text-muted">
                                        Создано: <?php echo e($r->created_at->format('d.m.Y H:i')); ?>

                                    </small>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                  
                    <div class="modal fade" id="cancelModal<?php echo e($r->id); ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Подтверждение отмены</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p>Вы уверены, что хотите отменить бронирование на 
                                    <strong><?php echo e(\Illuminate\Support\Carbon::parse($r->date)->format('d.m.Y')); ?> <?php echo e($r->time); ?></strong> 
                                    для <?php echo e($r->guests); ?> гостей?</p>
                                    
                                    <?php if($r->status === 'confirmed'): ?>
                                        <div class="alert alert-warning">
                                            <i class="bi bi-exclamation-triangle"></i> 
                                            Бронирование уже подтверждено. Отмена может быть невозможна.
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Нет</button>
                                    <form action="<?php echo e(route('reservations.cancel', $r->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-danger">
                                            Да, отменить
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="mt-3">
                    <?php echo e($reservations->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/profile/reservations.blade.php ENDPATH**/ ?>