

<?php $__env->startSection('title', $category->name); ?>
<style>
    .hover-shadow:hover { 
        transform: translateY(-5px); 
        box-shadow: 0 10px 20px rgba(0,0,0,0.15)!important; 
    }
    .transition { 
        transition: all 0.3s ease; 
    }
    .form-search-menu {
    width: 40%;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center rounded-pill" role="alert" style="position:fixed; top:75px; right: 40; z-index:100; max-width: 500px; margin: 0 auto 30px;">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <!-- Заголовок -->
    <h1 class="text-center mb-5 display-5 fw-bold"><?php echo e($category->name); ?></h1>
    
    <?php if($category->description): ?>
        <p class="lead text-muted text-center mb-5"><?php echo e($category->description); ?></p>
    <?php endif; ?>

        <!-- Форма поиска -->
    <div class="form-search-menu text-center mb-5 ms-auto me-auto">
        <form action="<?php echo e(route('menu.category', $category->slug)); ?>" method="GET" class="d-inline-block w-100" style="max-width: 500px;">
            <div class="position-relative">
                <input type="text" 
                    class="form-control rounded-pill py-3 px-4 border-danger" 
                    name="search" 
                    placeholder="Поиск в категории <?php echo e($category->name); ?>..."
                    value="<?php echo e($search ?? ''); ?>">
                <button type="submit" class="btn btn-danger rounded-pill position-absolute end-0 top-0 bottom-0 m-1 px-4">
                    Найти
                </button>
            </div>
        </form>
    </div>

    <!-- Кнопки категорий -->
    <div class="d-flex flex-wrap justify-content-center gap-2 mb-5">
        <a href="<?php echo e(route('menu.index')); ?>" 
           class="btn btn-outline-danger rounded-pill px-4">
            <i class="bi bi-arrow-left"></i> Всё меню
        </a>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('menu.category', $cat->slug)); ?>"
               class="btn <?php echo e($cat->id === $category->id ? 'btn-danger' : 'btn-outline-danger'); ?> rounded-pill px-4">
                <?php echo e($cat->name); ?>

                <span class="badge bg-light text-dark ms-1"><?php echo e($cat->dishes->count()); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Заголовок результатов поиска -->
    <?php if($search): ?>
        <div class="alert alert-info text-center mb-4">
            <h5 class="mb-0">
                Найдено блюд: <?php echo e($dishes->total()); ?> по запросу "<?php echo e($search); ?>"
                <?php if($dishes->count() < $dishes->total()): ?>
                    (показано <?php echo e($dishes->count()); ?> из <?php echo e($dishes->total()); ?>)
                <?php endif; ?>
            </h5>
            <a href="<?php echo e(route('menu.category', $category->slug)); ?>" class="text-muted small">
                Показать все блюда категории
            </a>
        </div>
    <?php endif; ?>

    <!-- Сообщение если нет блюд -->
            <?php if($dishes->isEmpty()): ?>
            <div class="alert alert-warning text-center py-5">
                <h4>
                    <?php if($search): ?>
                        По запросу "<?php echo e($search); ?>" ничего не найдено
                    <?php else: ?>
                        В этой категории пока нет блюд
                    <?php endif; ?>
                </h4>
                <p>
                    <?php if($search): ?>
                        Попробуйте изменить поисковый запрос
                        <br>
                        <a href="<?php echo e(route('menu.category', $category->slug)); ?>" class="btn btn-sm btn-outline-danger mt-2">
                            Показать все блюда категории
                        </a>
                    <?php else: ?>
                        Но мы уже работаем над новыми рецептами!
                    <?php endif; ?>
                </p>
            </div>
        <?php else: ?>
        <!-- Сетка блюд -->
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
            <?php $__currentLoopData = $dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card h-100 shadow-sm hover-shadow transition">
                        <?php if($dish->url_image): ?>
                            <img src="/storage/<?php echo e($dish->url_image); ?>" 
                                 class="card-img-top" 
                                 style="height: 200px; object-fit: cover;" 
                                 alt="<?php echo e($dish->name); ?>">
                        <?php else: ?>
                            <div class="bg-light border-bottom d-flex align-items-center justify-content-center" 
                                 style="height: 200px;">
                                <i class="bi bi-image fs-1 text-muted"></i>
                            </div>
                        <?php endif; ?>

                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title fs-6 fw-bold">
                                <?php echo e($dish->name); ?>

                                <?php if($dish->is_spicy): ?><i class="bi bi-fire text-danger ms-1"></i><?php endif; ?>
                                <?php if($dish->is_vegetarian): ?><i class="bi bi-leaf text-success ms-1"></i><?php endif; ?>
                            </h5>

                            <?php if($dish->description): ?>
                                <p class="card-text text-muted small flex-grow-1">
                                    <?php echo e(Str::limit($dish->description, 70)); ?>

                                </p>
                            <?php endif; ?>

                            <div class="mt-auto d-flex justify-content-between align-items-end">
                                <span class="h5 text-danger mb-0"><?php echo e(number_format($dish->price, 0, '', ' ')); ?> ₽</span>
                                
                                <form action="<?php echo e(route('cart.add', $dish)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm rounded-pill">
                                        <i class="bi bi-cart-plus"></i> В корзину
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    

        <!-- Наша кастомная надпись о пагинации -->
        <?php if($dishes->total() > 0): ?>
            <div class="text-center text-muted small mb-3">
                Показано от
                <span class="fw-bold"><?php echo e($dishes->firstItem()); ?></span>
                до 
                <span class="fw-bold"><?php echo e($dishes->lastItem()); ?></span>
                из 
                <span class="fw-bold"><?php echo e($dishes->total()); ?></span>
                <?php if($dishes->total() == 1): ?>
                    результата
                <?php elseif($dishes->total() >= 2 && $dishes->total() <= 4): ?>
                    результата
                <?php else: ?>
                    результатов
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Сама пагинация -->
        <?php if($dishes->hasPages()): ?>
            <div class="mt-3 text-center">
                <?php echo e($dishes->withQueryString()->links('pagination::bootstrap-5')); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/menu/category.blade.php ENDPATH**/ ?>