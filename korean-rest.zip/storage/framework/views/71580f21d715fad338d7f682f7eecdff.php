

<?php $__env->startSection('title', 'Создать блюдо'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Создать блюдо</h1>
        <a class="btn" href="<?php echo e(route('admin.dishes.index')); ?>">← Назад к списку</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="<?php echo e(route('admin.dishes.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="name">Название блюда *</label>
                <input type="text" 
                       id="name" 
                       name="name" 
                       value="<?php echo e(old('name')); ?>" 
                       placeholder="Например: Пицца Маргарита" 
                       required 
                       autofocus>
                <small>Максимум 255 символов</small>
            </div>

            <div class="form-group">
                <label for="price">Цена *</label>
                <input type="number" 
                       id="price" 
                       name="price" 
                       value="<?php echo e(old('price')); ?>" 
                       placeholder="0" 
                       min="0" 
                       step="1" 
                       required>
                <small>Цена в рублях</small>
            </div>

            <div class="form-group">
                <label for="description">Описание</label>
                <textarea id="description" 
                          name="description" 
                          rows="4" 
                          placeholder="Подробное описание блюда..."><?php echo e(old('description')); ?></textarea>
                <small>Необязательное поле</small>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn primary">Создать блюдо</button>
                <a class="btn" href="<?php echo e(route('admin.dishes.index')); ?>">Отмена</a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/admin/dishes/create.blade.php ENDPATH**/ ?>