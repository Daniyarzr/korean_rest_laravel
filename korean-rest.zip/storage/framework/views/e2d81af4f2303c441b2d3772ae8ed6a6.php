

<?php $__env->startSection('title', 'Редактировать пользователя'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Редактировать пользователя #<?php echo e($user->id); ?></h1>
        <a class="btn" href="<?php echo e(route('admin.users.index')); ?>">← Назад к списку</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <!-- Форма редактирования -->
        <form method="POST" action="<?php echo e(route('admin.users.update', $user)); ?>" id="editForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name">Имя *</label>
                <input type="text" 
                       id="name" 
                       name="name" 
                       value="<?php echo e(old('name', $user->name)); ?>" 
                       placeholder="Введите имя пользователя" 
                       required 
                       autofocus>
                <small>Максимум 255 символов</small>
            </div>

            <div class="form-group">
                <label for="email">Email *</label>
                <input type="email" 
                       id="email" 
                       name="email" 
                       value="<?php echo e(old('email', $user->email)); ?>" 
                       placeholder="user@example.com" 
                       required>
                <small>Должен быть уникальным</small>
            </div>

            <div class="form-group">
                <label for="password">Пароль</label>
                <input type="password" 
                       id="password" 
                       name="password" 
                       placeholder="Оставьте пустым, если не меняется">
                <small>Минимум 6 символов. Заполняйте только для смены пароля</small>
            </div>

            <div class="form-group">
                <label for="role">Роль *</label>
                <select id="role" name="role" required>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role); ?>" <?php echo e((old('role', $user->role) == $role) ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($role)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small>admin — полный доступ, manager — ограниченный, user — базовый</small>
            </div>

            <div class="user-info mt-4 p-3 bg-gray-50 rounded">
                <h3 class="font-semibold">Информация о пользователе</h3>
                <p><strong>Создан:</strong> <?php echo e($user->created_at->format('d.m.Y H:i')); ?></p>
                <p><strong>Обновлён:</strong> <?php echo e($user->updated_at->format('d.m.Y H:i')); ?></p>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn primary">Сохранить изменения</button>
                <a class="btn" href="<?php echo e(route('admin.users.index')); ?>">Отмена</a>
            </div>
        </form>

        <!-- Форма удаления - ОТДЕЛЬНО, после формы редактирования -->
        <?php if(auth()->id() !== $user->id): ?>
            <div class="mt-6 pt-6 border-t border-gray-200">
                <h3 class="font-semibold text-red-600 mb-2">Опасная зона</h3>
                <form method="POST" 
                      action="<?php echo e(route('admin.users.destroy', $user)); ?>"
                      onsubmit="return confirm('Вы уверены, что хотите удалить пользователя <?php echo e($user->name); ?>? Это действие нельзя отменить.');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn danger">Удалить пользователя</button>
                    <span class="text-sm text-gray-500 ml-2">Это действие необратимо</span>
                </form>
            </div>
        <?php else: ?>
            <div class="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded">
                <p class="text-yellow-700">
                    <strong>Внимание:</strong> Вы не можете удалить свой собственный аккаунт.
                </p>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\korean-restaurant\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>